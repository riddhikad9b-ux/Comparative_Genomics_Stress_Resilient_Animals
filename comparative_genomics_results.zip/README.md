# 🧬 Comparative Genomics and Structural Biophysics of Tardigrade Stress Proteins

A comprehensive computational pipeline exploring the evolutionary divergence, electrostatic shielding, and intrinsic disorder of extremotolerant tardigrade proteins (*Ramazzottius varieornatus* and *Hypsibius exemplaris*) relative to model metazoan organisms.

## 📌 Project Overview
Tardigrades exhibit extraordinary tolerance to ionizing radiation, extreme desiccation, and oxidative stress. This repository contains automated Python scripts to:
1. **Construct Multi-FASTA datasets** of stress-resilient proteins (Dsup, CAHS1) alongside mitochondrial antioxidant orthologs (MnSOD).
2. **Compute global sequence identity matrices** and neighbor-joining phylogenetic trees.
3. **Quantify biophysical properties** (molecular weight, theoretical isoelectric points, and basic amino acid enrichment) using Biopython.
4. **Analyze AlphaFold 3D structures** to evaluate per-residue confidence (pLDDT) and intrinsic disorder (IDR).
5. **Map electrostatic sliding-window basic residue densities** directly into PDB B-factor columns for structural visualization.

## 🗂️ Repository Structure
- `extremophile_targets.fasta` - Multi-FASTA database
- `sequence_identity_matrix.csv` - Pairwise percentage identity matrix
- `biophysical_properties.csv` - Molecular weights, pI, and basic residue percentages
- `dsup_electrostatic_mapped.pdb` - Custom PDB with electrostatic sliding-window scores in B-factor
